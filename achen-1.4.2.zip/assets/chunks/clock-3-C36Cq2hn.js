import{c}from"./index-DaX8qLrE.js";const o=c("clock-3",[["path",{d:"M12 6v6h4",key:"135r8i"}],["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]]);export{o as C};
