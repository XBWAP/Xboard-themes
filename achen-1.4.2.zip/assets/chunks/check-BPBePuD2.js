import{c}from"./index-DaX8qLrE.js";const o=c("check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);export{o as C};
