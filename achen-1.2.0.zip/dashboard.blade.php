<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover" />
  <meta name="theme-color" content="#f5f5f7" />
  <meta name="description" content="{{$description}}" />
  <title>{{$title}}</title>
  <link rel="stylesheet" href="/theme/{{$theme}}/assets/app.css?v={{$version}}" />
</head>
<body>
<script>
  window.routerBase = "/";
  window.settings = {
    title: '{{$title}}',
    description: '{{$description}}',
    assets_path: '/theme/{{$theme}}/assets',
    theme: { color: '{{ $theme_config["theme_color"] ?? "default" }}' },
    version: '{{$version}}',
    background_url: '{{$theme_config["background_url"] ?? ""}}',
    logo: '{{$logo}}',
    downloads: {
      android: {!! json_encode($theme_config["android_url"] ?? "") !!},
      windows: {!! json_encode($theme_config["windows_url"] ?? "") !!},
      macos: {!! json_encode($theme_config["macos_url"] ?? "") !!},
      ios: {!! json_encode($theme_config["ios_url"] ?? "") !!}
    },
    i18n: ['zh-CN', 'en-US']
  };
</script>
<div id="app"></div>
<script type="module" src="/theme/{{$theme}}/assets/app.js?v={{$version}}"></script>
{!! $theme_config['custom_html'] ?? '' !!}
</body>
</html>
